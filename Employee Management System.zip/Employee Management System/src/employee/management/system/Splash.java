package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Splash extends JFrame implements ActionListener {
    JLabel heading;
    JLabel image;
    JButton clickhere;

    Splash() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        heading = new JLabel("EMPLOYEE MANAGEMENT SYSTEM", SwingConstants.CENTER);
        heading.setFont(new Font("serif", Font.PLAIN, 60));
        heading.setForeground(Color.BLACK);
        add(heading);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/front.jpg"));
        Image i2 = i1.getImage();
        ImageIcon i3 = new ImageIcon(i2);
        image = new JLabel(i3);
        image.setHorizontalAlignment(SwingConstants.CENTER);
        add(image);

        clickhere = new JButton("CLICK HERE TO CONTINUE");
        clickhere.setBackground(Color.BLACK);
        clickhere.setForeground(Color.WHITE);
        clickhere.addActionListener(this);
        add(clickhere);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        setVisible(true);

        addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                updateComponents();
            }
        });

        new Thread(() -> {
            while (true) {
                heading.setVisible(false);
                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                heading.setVisible(true);
                try {
                    Thread.sleep(500);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void updateComponents() {
        int width = getWidth();
        int height = getHeight();

        int textHeight = height / 5;

        heading.setBounds(0, textHeight / 4, width, textHeight / 2);
        heading.setFont(new Font("serif", Font.PLAIN, textHeight / 3));

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/front.jpg"));
        Image i2 = i1.getImage().getScaledInstance(width, height - textHeight, Image.SCALE_DEFAULT);
        image.setIcon(new ImageIcon(i2));
        image.setBounds(0, textHeight, width, height - textHeight);

        clickhere.setBounds(width / 2 - 150, height - 100, 300, 50);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Login(); 
    }

    public static void main(String args[]) {
        new Splash();
    }
}
